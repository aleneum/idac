package totem.visual;

public interface TVisualization{
	public void kick();
	public void hat();
	public void snare();
	public void draw();
}
